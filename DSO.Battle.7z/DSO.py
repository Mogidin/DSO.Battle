# -*- coding: UTF-8 -*-

ImgDir = "img/"
Unit = {"Rekruten":ImgDir+"Rekruten.png", \
	"Soldaten":ImgDir+"Soldaten.png", \
	"Maat":ImgDir+"Maat.png"}
MarkTxt = "Mark"
Mark = ImgDir+"mark.png"
